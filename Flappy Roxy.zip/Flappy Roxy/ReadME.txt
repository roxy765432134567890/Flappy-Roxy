This was coded fully by roxy132 with the help of heeps and the coding Den discord server


don't skid u little SKID!